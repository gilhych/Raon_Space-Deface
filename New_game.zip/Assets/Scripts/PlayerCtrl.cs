﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerCtrl : MonoBehaviour
{
    public Image CursorGageImage;
    public float Timer = 0;
    private Vector3 ScreenCenter;
    private float GageTimer;
    public Text texttimer;
    private AudioSource audiosource;
    public AudioClip bgm;

    // Start is called before the first frame update
    void Start()
    {
        ScreenCenter = new Vector3(Camera.main.pixelWidth /2 , Camera.main.pixelHeight /2);
    }

    // Update is called once per frame
    void Update()
    {
        audiosource = GetComponent<AudioSource>();
        Ray ray = Camera.main.ScreenPointToRay(ScreenCenter);
        RaycastHit hit;
        CursorGageImage.fillAmount = GageTimer;

        if (Physics.Raycast(ray, out hit, 100.0f))
        {
            GageTimer += 1.0f / 2.0f * Time.deltaTime;

            if (GageTimer >= 0.15)
            {
                Destroy(hit.transform.gameObject);
                GageTimer = 0;
                audiosource.PlayOneShot(bgm);
            }          
        }
        else
            GageTimer = 0;

        if (Timer <= 60)
        {
            Timer += Time.deltaTime;
        }
        else
        {
            SceneManager.LoadScene("Clear");
        }
        texttimer.text = string.Format("시간: {0:N0}", Timer);

    }
}
