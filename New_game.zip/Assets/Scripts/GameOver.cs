﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameOver : MonoBehaviour
{
    public float Health = 3;
    public Text TextHealth;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        TextHealth.text = "목숨: " + Health;

        if(Health <= 0)
        {
            SceneManager.LoadScene("GameOver");
        }
    }

    void OnCollisionEnter(Collision other)
    {
            if (other.gameObject.tag == "enemy")
            {
                Health--;
                Destroy(other.transform.gameObject);
            }
    }
}
