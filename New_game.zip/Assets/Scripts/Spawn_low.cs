﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn_low : MonoBehaviour
{
    public bool enableSpawn = false;
    public GameObject Enemy;
    private float MoveSpeed = 20.0f;

    void SpawnEnemy()
    {
        float randomX = Random.Range(-9f, 9f);
        float randomY = Random.Range(-7.5f, 7.5f);
        if (enabled)
        {
            GameObject enemy = (GameObject)Instantiate(Enemy, new Vector3(randomX, randomY, 14f), Quaternion.identity);
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("SpawnEnemy", 0, 1);
    }

    // Update is called once per frame
    void Update()
    {
        this.transform.position += this.transform.forward * 5.0f * Time.deltaTime;
    }
}
